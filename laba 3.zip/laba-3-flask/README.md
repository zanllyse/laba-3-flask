# laba-3-flask
/project-folder
  /templates
    index.html
    about.html
  app.py
